import 'package:flutter/material.dart';
import 'package:training_moveon/utility/constants/app_spacing.dart';
import 'package:training_moveon/utility/constants/asset_manger.dart';
import 'package:training_moveon/utility/constants/colors.dart';
import 'package:training_moveon/utility/constants/font_manager.dart';
import 'package:training_moveon/utility/constants/style_manager.dart';
import 'package:training_moveon/utility/constants/values_manager.dart';
import '../widgets/product_details_widget/product_basic_details.dart';
import '../widgets/product_details_widget/product_color_and_size.dart';
import '../widgets/product_details_widget/product_descriptions.dart';
import '../widgets/product_details_widget/product_reviews.dart';
import '../widgets/product_details_widget/product_specifications.dart';
import '../widgets/product_details_widget/select_product_shipping_method.dart';
import '../widgets/product_details_widget/seller_information.dart';
import '../widgets/product_details_widget/you_may_like_widget.dart';

class CustomScrollViewWidget extends StatefulWidget {
  const CustomScrollViewWidget({super.key});

  @override
  State<CustomScrollViewWidget> createState() => _CustomScrollViewWidgetState();
}

class _CustomScrollViewWidgetState extends State<CustomScrollViewWidget> {
  late ScrollController _scrollController;
  final List<String> _sizeList = ["S", "M", "L", "XL"];
  double top = 0;
  bool isSliverAppBarHide = false;
  bool isIconHide = true;

  void _scrollListener() {
    if (_scrollController.offset >= 700) {
      setState(() {
        isSliverAppBarHide = true;
      });
    }else {
      setState(() {
        isSliverAppBarHide = false;
      });
    }
  }

  void _sliverAppbar(){
    if(_scrollController.offset > 100){
      setState(() {
        isIconHide = false;
      });
    }else{
      setState(() {
        isIconHide = true;
      });
    }
  }

  @override
  void initState() {
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    _scrollController.addListener(_sliverAppbar);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhiteColor,
      body: CustomScrollView(
        controller: _scrollController,
        shrinkWrap: true,
        slivers: [
          SliverAppBar(
            expandedHeight: 360,
            pinned: true,
            backgroundColor: kWhiteColor,
            automaticallyImplyLeading: false,
            actions: [
              isIconHide ?
              CircleAvatar(
                backgroundColor: k000000.withOpacity(0.5),
                radius: AppRadius.r20,
                child: const Icon(
                  Icons.search,
                  size: AppSize.s20,
                  color: kWhiteColor,
                ),
              ) :
              const SizedBox(),
              AppSpacing.horizontalSpacing8,
              isIconHide ?
              CircleAvatar(
                backgroundColor: k000000.withOpacity(0.5),
                radius: AppRadius.r20,
                child: const Icon(
                  Icons.more_vert,
                  size: AppSize.s20,
                  color: kWhiteColor,
                ),
              ) :
              const SizedBox(),
              AppSpacing.horizontalSpacing16,
            ],
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.all(16),
              title: LayoutBuilder(
                builder: (context, constraints) {
                  top = constraints.biggest.height;
                  return AnimatedOpacity(
                    duration: const Duration(milliseconds: 100),
                    opacity: top <= 250 ? 1.0 : 0.0,
                    child: Expanded(
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {},
                            child: const Icon(
                              Icons.arrow_back,
                              size: AppSize.s24,
                              color: kBlackColor,
                            ),
                          ),
                          AppSpacing.horizontalSpacing8,
                          Text(
                            "Product Details",
                            style: getBoldStyle(
                              color: kTextBlackColor,
                              fontSize: FontSize.s16,
                            ),
                          ),
                          const Spacer(),
                          CircleAvatar(
                            backgroundColor: k000000.withOpacity(0.5),
                            radius: AppRadius.r16,
                            child: InkWell(
                              onTap: (){},
                              child: const Icon(
                                Icons.search,
                                size: AppSize.s16,
                                color: kWhiteColor,
                              ),
                            ),
                          ),
                          AppSpacing.horizontalSpacing16,
                          CircleAvatar(
                            backgroundColor: k000000.withOpacity(0.5),
                            radius: AppRadius.r16,
                            child: const Icon(
                              Icons.shopping_cart_outlined,
                              size: AppSize.s16,
                              color: kWhiteColor,
                            ),
                          ),
                          AppSpacing.horizontalSpacing16,
                          InkWell(
                            onTap: (){},
                            splashFactory: NoSplash.splashFactory,
                            child: const Icon(
                              Icons.more_vert,
                              size: AppSize.s16,
                              color: kBlackColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              background: Image.asset(
                ImageAssets.sliderPng,
                fit: BoxFit.fill,
              ),
            ),
          ),
          isSliverAppBarHide
              ? SliverLayoutBuilder(builder: (context, sliverConstrains) {
                  top = sliverConstrains.scrollOffset <= 944 ? 1.0 : 0.0;
                  return SliverAppBar(
                    pinned: true,
                    toolbarHeight: 12,
                    expandedHeight: 100,
                    backgroundColor: Colors.white,
                    automaticallyImplyLeading: false,
                    flexibleSpace: FlexibleSpaceBar(
                      centerTitle: true,
                      titlePadding: const EdgeInsets.all(16),
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              _scrollController.animateTo(
                                960,
                                duration: const Duration(milliseconds: 500),
                                curve: Curves.linear,
                              );
                            },
                            child: Text(
                              "Seller information",
                              style: getBoldStyle(
                                  color: kTextBlackColor, fontSize: 10),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              _scrollController.jumpTo(1741);
                            },
                            child: Text(
                              "Reviews",
                              style: getBoldStyle(
                                  color: kTextBlackColor, fontSize: 10),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              _scrollController.jumpTo(2467);
                            },
                            child: Text(
                              "Product Descriptions",
                              style: getBoldStyle(
                                  color: kTextBlackColor, fontSize: 10),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                })
              : const SliverToBoxAdapter(),
          const ProductBasicDetails(),
          sliverDivider(),
          ProductColorAndSize(sizeList: _sizeList),
          sliverDivider(),
          const ProductShippingMethod(),
          sliverDivider(),
          const SellerInformation(),
          sliverDivider(),
          const ProductSpecifications(),
          sliverDivider(),
          const ProductReviews(),
          sliverDivider(),
          const ProductDescription(),
          sliverDivider(),
          const YouMayLike(),
        ],
      ),
    );
  }

  SliverToBoxAdapter sliverDivider() {
    return const SliverToBoxAdapter(
      child: Divider(
        thickness: 8,
        color: kDDDDDD,
      ),
    );
  }
}
